<?php
  
		$message=shell_exec("./switch.sh");
		print_r($message);

?> 
